<?php
/**
 * @version		1.0.0
 * @package		Joomla
 * @subpackage	JahanPay Payment for eShop
 * @author  	Module Bank -::- Seyed Hamzeh Fazeli
 * @copyright	Copyright (C) 2014 Module Bank - All rights reserved.
 * @license		do not copy please. for order or technical support visit me at http://www.modulebank.ir/
 */
// no direct access
defined('_JEXEC') or die();

class os_jahanpay extends os_payment
{
	/**
	 * Constructor functions, init some parameter
	 *
	 * @param object $config
	 */
	public function __construct($params)
	{
        $config = array(
            'type' => 0,
            'show_card_type' => false,
            'show_card_holder_name' => false
        );
        parent::__construct($params, $config);
	}
	/**
	 * Process Payment
	 *
	 * @param array $params        	
	 */
	public function processPayment($data)
	{
		$siteUrl = JURI::base();
		$countryInfo = EshopHelper::getCountry($data['payment_country_id']);
		/*
		$countProduct = 1;
		foreach ($data['products'] as $product)
		{
			$this->setData('item_name_' . $countProduct, $product['product_name']);
			$this->setData('item_number_' . $countProduct, $product['product_sku']);
			$this->setData('amount_' . $countProduct, $product['price']);
			$this->setData('quantity_' . $countProduct, $product['quantity']);
			$this->setData('weight_' . $countProduct, $product['weight']);
			$countOption = 0;
			foreach ($product['option_data'] as $option)
			{
				$this->setData('on'.$countOption.'_'.$countProduct, $option['option_name']);
				$this->setData('os'.$countOption.'_'.$countProduct, $option['option_value']);
				$countOption++;
			}
			$countProduct++;
		}
		if ($data['discount_amount_cart'])
		{
			$this->setData('discount_amount_cart', $data['discount_amount_cart']);
		}
		*/
		// return = $siteUrl . 'index.php?option=com_eshop&view=checkout&layout=complete';
		// cancel = $siteUrl . 'index.php?option=com_eshop&view=checkout&layout=cancel&id=' . $data['order_id'];
		$callBack = $siteUrl . 'index.php?option=com_eshop&task=checkout.verifyPayment&payment_method=os_jahanpay&oID='.$data['order_id'];
		$transaction->custom = round(1,9999999);


		$client   = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$res      = $client->requestpayment($this->params->get('jahanpay_api'), $data['total'], $callBack, $transaction->custom);
		if($res['result'] == 1)
		{
			@session_start();
			$_SESSION['orderID'] = $transaction->custom;
			$_SESSION['amount']  = $data['total'];
			$_SESSION['au']      = $res['au'];
			echo '<div style="display:none;">'.$res['form'].'</div><script>document.forms[0].submit();</script>';
			//$this->url = "http://www.jpws.me/pay_invoice/".$res;
			//$this->submitPost();
		}
		else
		{
			echo '<p style="font:12px Tahoma; direction:rtl;text-align:center;color:#ff0000">خطای غیر منتظره ('.$res['result'].') !!!</p>';
		}
		exit;
	}

	/**
	 * Validate the post data from jahanpay to our server
	 *
	 * @return string
	 */
	protected function validate()
	{
		//$errNum = "";
		//$errStr = "";
		//$urlParsed = parse_url($this->url);
		//$host = $urlParsed['host'];
		//$path = $urlParsed['path'];
		//$postString = '';
		//$response = '';

		@session_start();
		$au      = $_SESSION['au'];
		$orderID = (int)$_SESSION['orderID'];
		$amount  = (int)$_SESSION['amount'];
		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$res    = $client->verification($this->params->get('jahanpay_api'), $amount, $au, $orderID, $_POST + $_GET );
		$this->logGatewayData(' OrderID: ' . $orderID . ' au:'.$au . ' amount:'.$amount . ' res:'.$res . ' time:'.date('Y/m/d H:i:s') );
		if($res['result'] == 1)
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">پرداخت با موفقیت انجام شد.<br />شماره پیگیری : '.$au.'<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return true;
		}
		else
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">خطا در پرداخت.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return false;
		}
	}
	/**
	 * Process payment
	 */
	public function verifyPayment()
	{
		$row = JTable::getInstance('Eshop', 'Order');
		$id = $_REQUEST['oID']; //$this->postData['custom'];
		$row->load($id);
		if ($row->order_status_id == EshopHelper::getConfigValue('complete_status_id'))
		{
			echo ('<p style="font:bold 12px tahoma; color:#FF0000; direction:rtl; text-align:center;">پرداخت قبلا ثبت شده.<br /><a href="./?">برای ادامه کلیک کنید.</a></p>');
			return false;
		}
		$ret = $this->validate();
		$currency = new EshopCurrency();
		if ($ret)
		{
			@session_start();
			$au      = $_SESSION['au'];
			$orderID = (int)$_SESSION['orderID'];
			$amount  = (int)$_SESSION['amount'];
			$row->transaction_id = $au; //$this->postData['txn_id'];
			$row->order_status_id = EshopHelper::getConfigValue('complete_status_id');
			$row->store();
			EshopHelper::completeOrder($row);
			//Send confirmation email here
			if (EshopHelper::getConfigValue('order_alert_mail'))
			{
				EshopHelper::sendEmails($row);
			}
			return true;
		}
		else
		{
			return false;
		}
	}
}